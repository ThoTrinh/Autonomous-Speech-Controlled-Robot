#!/bin/bash

_files_dir=$(dirname $0)
cp $_files_dir/src/scripts/*.py $_files_dir/src/